daten auswerten:

Bias messung zu y scan bei S1: 20161205_biasing_yscan oder I_photo_U_bias (null Strom, wenn beleutung �ber dem Kontakt, arb. units, Datum der Messung wei� ich nicht): Frage: welches objektiv wurde verwendet: vmtl 100x
z scan f�r esr contrast mittels python script bei verschiedenen Leistungen: 20161027_zscan_2mW, 20161027_zscan_1mW
	wichtig f�r analyse, wo esr detektiert werden soll: im Strom maximum?!
	
Kennlinien S1 sond so weit ganz ok: S1_pedmr_test_ProbenvergleichS1_S2 Kennlinie S1 dark, ...